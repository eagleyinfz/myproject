namespace simdutf {
// deliberately empty
}